package dgtic.core;

import dgtic.core.model.entities.Remision;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.RemisionRepository;
import dgtic.core.repository.TipoPaqueteRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.Optional;

@SpringBootTest
public class RemisionesTest {

    @Autowired
    RemisionRepository remisionRepository;

    @Autowired
    TipoPaqueteRepository tipoPaqueteRepository;
    @Test
    void buscarTodasRemisiones(){
        System.out.println("Buscando Todas las Remesiones");
        remisionRepository.findAll().forEach(System.out::println);
    }

    @Test
    void buscarRemisionPorId(){
        System.out.println("Buscar Remision Por Id");
        Optional<Remision> op = remisionRepository.findById(2);
        Remision remision = op.get();
        System.out.println("Cliente: "+remision.getCliente()+
                " Nombre del paquete: "+remision.getTipoPaquete().getNombrePaquete()+
                " Fecha de entrega "+ remision.getFechaEntrega());
    }

    @Test
    void buscarPorCliente(){
        System.out.println("Buscando remision por cliente ");
        Optional<Remision> op = remisionRepository.findByCliente("Juan Lopez");
        Remision remision = op.get();
        System.out.println(remision.getIdRemision()+" Tipo de paquete: "+remision.getTipoPaquete().getNombrePaquete() + " Fecha de Entrega: "+ remision.getFechaEntrega());
    }

    @Test
    void buscarRemisionPorFecha(){
        System.out.println("Buscar remisiones despues de una fecha");
        LocalDateTime fecha = LocalDateTime.of(2024, 10, 10, 19, 30);
        remisionRepository.findByFechaEntregaAfter(fecha).forEach(System.out::println);
    }

    @Test
    void buscarPorTipoPaquete(){
        System.out.println("Buscar Remision Por tipo de paqute");
        remisionRepository.buscarByTipoPaquete(tipoPaqueteRepository.findById(3).get())
                .forEach(System.out::println);
    }

}