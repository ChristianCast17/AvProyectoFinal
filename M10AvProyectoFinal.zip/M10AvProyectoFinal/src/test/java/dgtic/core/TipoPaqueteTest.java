package dgtic.core;

import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.TipoPaqueteRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@SpringBootTest
public class TipoPaqueteTest {

    @Autowired
    TipoPaqueteRepository tipoPaqueteRepository;

    @Test
    void buscarTodosTipoPaquete(){
        System.out.println("Buscar todos los paquetes");
        List<TipoPaquete> tipoPaquetes = tipoPaqueteRepository.findAll();
        tipoPaquetes.forEach(System.out::println);
    }
    @Test
    @Transactional
    void buscarTipoPquetePorId() {
        Optional<TipoPaquete> op = tipoPaqueteRepository.findById(3);
        TipoPaquete tipoPaquete = op.get();
        System.out.println(tipoPaquete.getNombrePaquete());
        System.out.println("Contiene los siguientes Equipos medicos: ");
        Iterable<EquipoMedico> iterable = tipoPaquete.getEquiposMedicos();
        iterable.forEach(equipoMedico ->
                System.out.println(equipoMedico.getNombreEquipo()));
    }

    @Test
    void buscarPorNombreAscendente(){
        System.out.println("Buscar por nombre y ordenado ascendentemente ");
        tipoPaqueteRepository.findByOrderByNombrePaqueteAsc().forEach(System.out::println);
    }

    @ParameterizedTest
    @ValueSource(strings = {"hombro","artro"})
    void buscarNombrePaqueteContaining(String substring){
        System.out.println("Buscar por contenido en nombre");
        tipoPaqueteRepository.findByNombreContenga(substring).forEach(System.out::println);
    }

    @Test
    void buscarRemisionesPorTipoPaquete(){
        System.out.println("Buscar todas la remisiones de un tipo de paquete");
        tipoPaqueteRepository.findRemisionesByTipoPaquete(2).forEach(System.out::println);
    }
}
