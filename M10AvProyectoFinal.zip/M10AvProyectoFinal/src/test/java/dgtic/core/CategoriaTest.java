package dgtic.core;

import dgtic.core.model.entities.Categoria;
import dgtic.core.repository.CategoriaRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

@SpringBootTest
public class CategoriaTest {

    @Autowired
    CategoriaRepository categoriaRepository;

    @Test
    void buscarTodasCategorias(){
        System.out.println("Buscar todas la categorias");
        List<Categoria> categorias = categoriaRepository.findAll();
        categorias.forEach(System.out::println);
    }

    @Test
    void buscarCategoriaById(){
        System.out.println("Buscar Categoria por ID");
        Optional<Categoria> op = categoriaRepository.findById(2);
        Categoria cat = op.get();
        System.out.println(cat.getNombreCategoria());
    }

    @Test
    void findByNombreContaining(){
        System.out.println("Buscar categoria con su nombre contiene");
        categoriaRepository.findByNombreCategoriaContaining("anes").forEach(System.out::println);
    }

    @Test
    void contAllCategorias(){
        System.out.println("Contar todas las categorias");
        System.out.println("El total de categorias son : "+categoriaRepository.countAllCategorias());

    }

    @Test
    void buscarCategoriasConEquipos(){
        System.out.println("Categorias que tienen Equipos Medicos");
        categoriaRepository.findCategoriasWithEquiposMedicos().forEach(categoria -> {
            System.out.println("Categoria: "+categoria.getNombreCategoria());
            categoria.getEquipoMedicos().forEach(equipoMedico -> {
                System.out.println(equipoMedico.getNombreEquipo());
            });
        });
    }


}
