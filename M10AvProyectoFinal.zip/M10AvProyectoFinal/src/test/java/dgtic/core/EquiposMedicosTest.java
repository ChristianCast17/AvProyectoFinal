package dgtic.core;

import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.EquipoMedicoRepository;
import dgtic.core.repository.TipoPaqueteRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@SpringBootTest
@Commit
public class EquiposMedicosTest {
    @Autowired
    EquipoMedicoRepository equipoMedicoRepository;
    @Autowired
    TipoPaqueteRepository tipoPaqueteRepository;

    @Test
    void buscarTodosEquiposMedicos(){
        System.out.println("Buscar todos los equipos medicos");
        List<EquipoMedico> equipoMedicos = equipoMedicoRepository.findAll();
        equipoMedicos.forEach(System.out::println);
    }

    @Test
    @Transactional
    void buscarEquipoMedicoPorId(){
        Optional<EquipoMedico> op = equipoMedicoRepository.findById(13);
        EquipoMedico equipoMedico = op.get();
        System.out.println(equipoMedico.getNombreEquipo()+" Y pertenece a la categoria "+
                equipoMedico.getCategoria().getNombreCategoria());
        equipoMedico.getPaquetes().forEach(a-> {
            System.out.println(a.getNombrePaquete());
        });
    }
    @Test
    void buscarPorNombreEquipoDesc(){
        System.out.println("Buscar Equipo por nombre y ordenado Descendentemente ");
        equipoMedicoRepository.findByOrderByNombreEquipoDesc().forEach(System.out::println);
    }
    @Test
    void buscarExistenciasMayorQue(){
        System.out.println("Buscar equipos medicos con mayor existencia");
        equipoMedicoRepository.findByExistenciasGreaterThan(7).forEach(System.out::println);
    }

    @Test
    @Transactional
    void agregarEliminarEquiposPaquete(){
        System.out.println("Agregar Equipo Medico a un paquete ");
        Optional<EquipoMedico> optional = equipoMedicoRepository.findById(2);
        EquipoMedico equipoMedico = optional.get();
        System.out.println("Equipo Medico seleccionado " + equipoMedico.getNombreEquipo());
        equipoMedico.addTipoPaquete(tipoPaqueteRepository.findById(2).get());
        equipoMedico.addTipoPaquete(tipoPaqueteRepository.findById(3).get());

        equipoMedicoRepository.save(equipoMedico);

        equipoMedicoRepository.findTipoPaqueteByEquipoMedico(2).forEach(System.out::println);
        System.out.println("Remover Tipo paquete de Equipo medico");
        equipoMedico.removeTipoPaquete(tipoPaqueteRepository.findById(3).get());
        equipoMedicoRepository.save(equipoMedico);
        equipoMedicoRepository.findTipoPaqueteByEquipoMedico(2).forEach(System.out::println);
    }


}
