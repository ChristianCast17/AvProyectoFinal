package dgtic.core;

import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.ProductoConsumible;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.ProductoConsumibleRepository;
import dgtic.core.repository.TipoPaqueteRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@SpringBootTest
@Commit
public class ProductoConsumibleTest {

    @Autowired
    ProductoConsumibleRepository productoConsumibleRepository;

    @Autowired
    TipoPaqueteRepository tipoPaqueteRepository;

    @Test
    void buscarTodosProductosConsumibles(){
        System.out.println("Buscar todos los Productos consumibles");
        productoConsumibleRepository.findAll().forEach(System.out::println);

    }

    @Test
    void buscarProductoConsumiblePorId(){
        System.out.println("Buscar Producto Consumible por ID ");
        Optional<ProductoConsumible> op = productoConsumibleRepository.findById(2);
        ProductoConsumible productoConsumible = op.get();
        System.out.println(productoConsumible.getNombreProducto()+" Descripcion:  "+
                productoConsumible.getDescripcion());
    }

    @Test
    void findByNombreProductoContaining(){
        System.out.println("Buscar producto consumibe que su nombre contiene ");
        productoConsumibleRepository.findByNombreProductoContaining("artros").forEach(System.out::println);
    }

    @Test
    void buscarProductoPortipoPaquete(){
        System.out.println("Buscar Producto Consumible Por su tipo de paquete");
        Optional<TipoPaquete> op = tipoPaqueteRepository.findById(2);
        TipoPaquete tipoPaquete = op.get();
        System.out.println("Tipo de paquete seleccionado "+tipoPaquete.getNombrePaquete());
        productoConsumibleRepository.findByTipoPaqueteId(2).forEach(System.out::println);

    }

    @Test
    @Transactional
    void agregarEliminarProductosPaquete(){
        System.out.println("Agregar Equipo Medico a un paquete ");
        Optional<ProductoConsumible> optional = productoConsumibleRepository.findById(2);
        ProductoConsumible productoConsumible = optional.get();
        System.out.println("Producto Cunsumible seleccionado " + productoConsumible.getNombreProducto());
        productoConsumible.addTipoPaquete(tipoPaqueteRepository.findById(2).get());
        productoConsumible.addTipoPaquete(tipoPaqueteRepository.findById(3).get());

        productoConsumibleRepository.save(productoConsumible);

        productoConsumibleRepository.findTipoPaqueteByProductoConsumible(2).forEach(System.out::println);
        System.out.println("Remover TipoPaquete de Producto Consumible");
        productoConsumible.removeTipoPaquete(tipoPaqueteRepository.findById(3).get());
        productoConsumibleRepository.save(productoConsumible);
        productoConsumibleRepository.findTipoPaqueteByProductoConsumible(2).forEach(System.out::println);
    }
}
