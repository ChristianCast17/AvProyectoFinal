CREATE TABLE Categoria (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(100) NOT NULL,

    CONSTRAINT uq_empleados UNIQUE (nombre_categoria)
);

CREATE TABLE equiposMedicos (
    id_equipo_medico INT AUTO_INCREMENT PRIMARY KEY,
    nombre_equipo VARCHAR(100) NOT NULL DEFAULT('Desconocido'),
    id_categoria INT NOT NULL,
    existencias INT NOT NULL CHECK(existencias>0),
    #id_equipo_x_paquete INT NOT NULL,

    CONSTRAINT uq_equiposMedicos UNIQUE (nombre_equipo, id_categoria),
    CONSTRAINT fk_equipos_categoria FOREIGN KEY (id_categoria) REFERENCES Categoria(id_categoria)

);

CREATE TABLE productoConsumible (
    id_producto_consumible INT AUTO_INCREMENT PRIMARY KEY,
    nombre_producto VARCHAR(100) NOT NULL,
    descripcion TEXT DEFAULT('Desconocido'),
    existencias INT NOT NULl,

    CONSTRAINT uq_producto UNIQUE (nombre_producto, descripcion)
);

CREATE TABLE tipoPaquete (
    id_tipo_paquete INT AUTO_INCREMENT PRIMARY KEY,
    nombre_paquete VARCHAR(100) NOT NULL
    #id_productos_x_paquete INT NOT NULL,
    #id_equipo_x_paquete INT NOT NULL,

);


CREATE TABLE Equipo_X_Paquete (
    id_equipo_x_paquete INT AUTO_INCREMENT PRIMARY KEY,
    id_tipo_paquete INT NOT NULL,
    id_equipo_medico INT NOT NULL,

    CONSTRAINT uq_equipo_x_paquete UNIQUE (id_equipo_medico)
);

CREATE TABLE Producto_X_Paquete (
    id_producto_x_paquete INT AUTO_INCREMENT PRIMARY KEY,
    id_tipo_paquete INT NOT NULL,
    id_producto_consumible INT NOT NULL,
    FOREIGN KEY (id_tipo_paquete) REFERENCES tipoPaquete(id_tipo_paquete),
    FOREIGN KEY (id_producto_consumible) REFERENCES productoConsumible(id_producto_consumible)

);

CREATE TABLE Remision (
    id_remision INT AUTO_INCREMENT PRIMARY KEY,
    cliente VARCHAR(25) NOT NULL,
    fecha_entrega DATETIME NOT NULL,
	 id_tipo_paquete INT NOT NULL,

    FOREIGN KEY (id_tipo_paquete) REFERENCES tipoPaquete(id_tipo_paquete)

);
