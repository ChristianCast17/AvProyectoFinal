
INSERT INTO categoria VALUES (1,"Equipos Artroscopicos");
INSERT INTO categoria VALUES (2,"Equipos de Anestecia");
INSERT INTO categoria VALUES (3,"Equipos Insuflacion y Lavado");

INSERT INTO Remision VALUES (1,'Juan Lopez', '2024-10-13 15:00:00', 1);
INSERT INTO Remision VALUES (2,'Sandra Tapia', '2024-10-12 16:00:00', 2);
INSERT INTO Remision VALUES (3,'Gloria Sanchez', '2024-10-11 17:00:00', 3);
INSERT INTO Remision VALUES (4,'Pablo Perez', '2024-10-10 18:00:00', 1);
INSERT INTO Remision VALUES (5,'Esteban Torres', '2024-10-9 19:00:00', 2);


INSERT INTO equiposmedicos VALUES (1,"Shaver",1,6);
INSERT INTO equiposmedicos VALUES (2,"Bomba de Irrigacion",3,6);
INSERT INTO equiposmedicos VALUES (3,"Maquina De Anestecia",2,6);
INSERT INTO equiposmedicos VALUES (4,"Bisturi",1,10);
INSERT INTO equiposmedicos VALUES (5,"Esponja de Limpieza",3,6);

INSERT INTO productoConsumible VALUES (1,"Cuchillas artroscópicas", "hace incisiones precisas en la articulación permitiendo la entrada de instrumentos",5);
INSERT INTO productoConsumible VALUES (2,"Anclas de sutura","se implantan en el hueso para anclar los hilos de sutura",5);
INSERT INTO productoConsumible VALUES (3,"Vaporizador de radiofrecuencia","utiliza radiofrecuencia para vaporizar tejido no deseado o dañado en la articulación. ",4);
INSERT INTO productoConsumible VALUES (4,"Cánulas artroscópicas","Tubos utilizados para mantener abiertos los puertos de acceso durante la artroscopia. ",3);
INSERT INTO productoConsumible VALUES (5,"Trocares desechables","Instrumentos puntiagudos utilizados para crear las vías de acceso iniciales en la piel y tejidos hacia la articulación. ",3);

INSERT INTO tipopaquete VALUES (1,"Paquete Artroscopia Rodilla");
INSERT INTO tipopaquete VALUES (2,"Paquete Artroscopia Hombro");
INSERT INTO tipopaquete VALUES (3,"Paquete Artroscopia Tobillo");