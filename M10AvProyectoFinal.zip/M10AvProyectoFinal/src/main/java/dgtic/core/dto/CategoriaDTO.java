package dgtic.core.dto;

import java.util.Objects;

public class CategoriaDTO {

    private Integer idCategoria;
    private String nombreCategoria;

    public CategoriaDTO() {
    }

    public CategoriaDTO(Integer idCategoria, String nombreCategoria) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoriaDTO that = (CategoriaDTO) o;
        return Objects.equals(getIdCategoria(), that.getIdCategoria()) && Objects.equals(getNombreCategoria(), that.getNombreCategoria());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdCategoria(), getNombreCategoria());
    }

    @Override
    public String toString() {
        return "CategoriaDTO{" +
                "idCategoria=" + idCategoria +
                ", nombreCategoria='" + nombreCategoria + '\'' +
                '}';
    }
}
