package dgtic.core.dto;

import java.util.Objects;

public class TipoPaqueteDTO {

    private Integer idTipoPaquete;

    private String nombrePaquete;

    public TipoPaqueteDTO() {
    }

    public TipoPaqueteDTO(Integer idTipoPaquete, String nombrePaquete) {
        this.idTipoPaquete = idTipoPaquete;
        this.nombrePaquete = nombrePaquete;
    }

    public Integer getIdTipoPaquete() {
        return idTipoPaquete;
    }

    public void setIdTipoPaquete(Integer idTipoPaquete) {
        this.idTipoPaquete = idTipoPaquete;
    }

    public String getNombrePaquete() {
        return nombrePaquete;
    }

    public void setNombrePaquete(String nombrePaquete) {
        this.nombrePaquete = nombrePaquete;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TipoPaqueteDTO that = (TipoPaqueteDTO) o;
        return Objects.equals(getIdTipoPaquete(), that.getIdTipoPaquete()) && Objects.equals(getNombrePaquete(), that.getNombrePaquete());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdTipoPaquete(), getNombrePaquete());
    }

    @Override
    public String toString() {
        return "TipoPaqueteDTO{" +
                "idTipoPaquete=" + idTipoPaquete +
                ", nombrePaquete='" + nombrePaquete + '\'' +
                '}';
    }
}
