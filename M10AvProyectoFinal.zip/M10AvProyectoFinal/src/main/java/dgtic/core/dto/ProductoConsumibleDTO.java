package dgtic.core.dto;

import java.util.Objects;

public class ProductoConsumibleDTO {

    private Integer idProductoConsumible;

    private String nombreProducto;

    private String descripcion;

    private Integer existencias;

    public ProductoConsumibleDTO() {
    }

    public ProductoConsumibleDTO(Integer idProductoConsumible, String nombreProducto, String descripcion, Integer existencias) {
        this.idProductoConsumible = idProductoConsumible;
        this.nombreProducto = nombreProducto;
        this.descripcion = descripcion;
        this.existencias = existencias;
    }

    public Integer getIdProductoConsumible() {
        return idProductoConsumible;
    }

    public void setIdProductoConsumible(Integer idProductoConsumible) {
        this.idProductoConsumible = idProductoConsumible;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getExistencias() {
        return existencias;
    }

    public void setExistencias(Integer existencias) {
        this.existencias = existencias;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductoConsumibleDTO that = (ProductoConsumibleDTO) o;
        return Objects.equals(getIdProductoConsumible(), that.getIdProductoConsumible()) && Objects.equals(getNombreProducto(), that.getNombreProducto()) && Objects.equals(getDescripcion(), that.getDescripcion()) && Objects.equals(getExistencias(), that.getExistencias());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdProductoConsumible(), getNombreProducto(), getDescripcion(), getExistencias());
    }

    @Override
    public String toString() {
        return "ProductoConsumibleDTO{" +
                "idProductoConsumible=" + idProductoConsumible +
                ", nombreProducto='" + nombreProducto + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", existencias=" + existencias +
                '}';
    }
}
