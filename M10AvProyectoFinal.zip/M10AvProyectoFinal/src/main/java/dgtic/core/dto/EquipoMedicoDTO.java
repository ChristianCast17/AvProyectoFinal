package dgtic.core.dto;

import java.util.Objects;

public class EquipoMedicoDTO {

    private int id;
    private String nombreEquipo;
    private int existencias;
    private String categoria;
    private String paquetes;

    public EquipoMedicoDTO() {
    }

    public EquipoMedicoDTO(int id, String nombreEquipo, int existencias, String categoria, String paquetes) {
        this.id = id;
        this.nombreEquipo = nombreEquipo;
        this.existencias = existencias;
        this.categoria = categoria;
        this.paquetes = paquetes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public int getExistencias() {
        return existencias;
    }

    public void setExistencias(int existencias) {
        this.existencias = existencias;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getPaquetes() {
        return paquetes;
    }

    public void setPaquetes(String paquetes) {
        this.paquetes = paquetes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EquipoMedicoDTO that = (EquipoMedicoDTO) o;
        return getId() == that.getId() && getExistencias() == that.getExistencias() && Objects.equals(getNombreEquipo(), that.getNombreEquipo()) && Objects.equals(getCategoria(), that.getCategoria()) && Objects.equals(getPaquetes(), that.getPaquetes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getNombreEquipo(), getExistencias(), getCategoria(), getPaquetes());
    }

    @Override
    public String toString() {
        return "EquipoMedicoDTO{" +
                "id=" + id +
                ", nombreEquipo='" + nombreEquipo + '\'' +
                ", existencias=" + existencias +
                ", categoria='" + categoria + '\'' +
                ", paquetes='" + paquetes + '\'' +
                '}';
    }

}
