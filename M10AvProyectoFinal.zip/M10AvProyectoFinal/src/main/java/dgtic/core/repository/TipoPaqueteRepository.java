package dgtic.core.repository;

import dgtic.core.model.entities.Categoria;
import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.Remision;
import dgtic.core.model.entities.TipoPaquete;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TipoPaqueteRepository extends JpaRepository<TipoPaquete,Integer> {

    //Consulta Derivada
    List<TipoPaquete> findByOrderByNombrePaqueteAsc();

    TipoPaquete findByNombrePaquete(String nombre);
    //Consulta Nombrada
    @Query(name = "TipoPaquete.buscarPorNombreContenga")
    List<TipoPaquete> findByNombreContenga(@Param("substring")String substring);

    //Consulta con Relacion
    @Query("SELECT g FROM TipoPaquete a  JOIN a.remisiones g WHERE a.idTipoPaquete = :idTipoPaquete")
    List<Remision> findRemisionesByTipoPaquete(@Param("idTipoPaquete") Integer idTipoPaquete);

}
