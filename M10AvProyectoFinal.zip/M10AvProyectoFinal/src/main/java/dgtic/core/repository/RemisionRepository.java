package dgtic.core.repository;

import dgtic.core.model.entities.Remision;
import dgtic.core.model.entities.TipoPaquete;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface RemisionRepository extends JpaRepository<Remision,Integer> {

    //Consulta Derivada
    Optional<Remision> findByCliente(String cliente);

    //Consulta Nombrada
    @Query(name = "Remision.findByFechaEntregaAfter")
    List<Remision> findByFechaEntregaAfter(@Param("fecha") LocalDateTime fecha);

    //Consulta Con Relacion
    @Query(name = "Remision.findByTipoPaquete")
    List<Remision> buscarByTipoPaquete(@Param("tipoPaquete") TipoPaquete tipoPaquete);

}
