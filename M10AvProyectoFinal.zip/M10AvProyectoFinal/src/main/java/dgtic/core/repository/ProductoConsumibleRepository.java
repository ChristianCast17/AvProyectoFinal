package dgtic.core.repository;

import dgtic.core.model.entities.ProductoConsumible;
import dgtic.core.model.entities.TipoPaquete;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductoConsumibleRepository extends JpaRepository<ProductoConsumible,Integer> {


    //Consulta Derivada
    List<ProductoConsumible> findByNombreProductoContaining(String substring);

    //Consulta Nombrada
    @Query(name = "ProductoConsumible.findByTipoPaqueteId")
    List<ProductoConsumible> findByTipoPaqueteId(@Param("idTipoPaquete") Integer idTipoPaquete);

    //Consulta con Relacion
    @Query("SELECT g FROM productoconsumible a  JOIN a.paquetes g WHERE a.idProductoConsumible = :idProductoConsumible")
    List<TipoPaquete> findTipoPaqueteByProductoConsumible(@Param("idProductoConsumible") Integer idProductoConsumible);

}

