package dgtic.core.repository;

import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.TipoPaquete;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EquipoMedicoRepository extends JpaRepository<EquipoMedico,Integer> {

    //Consulta Derivada
    List<EquipoMedico> findByOrderByNombreEquipoDesc();

    //Consulta Nombrada
    @Query(name = "EquipoMedico.findByExistenciasGreaterThan")
    List<EquipoMedico> findByExistenciasGreaterThan(@Param("existencias") Integer existencias);

    //Consulta con Relacion
    @Query("SELECT g FROM EquipoMedico a  JOIN a.paquetes g WHERE a.id = :idEquipoMedico")
    List<TipoPaquete> findTipoPaqueteByEquipoMedico(@Param("idEquipoMedico") Integer idEquipoMedico);

}
