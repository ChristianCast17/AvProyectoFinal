package dgtic.core.service.productoConsumible;

import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.model.entities.ProductoConsumible;
import dgtic.core.repository.ProductoConsumibleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoConsumibleServiceImpl implements ProductoConsumibleService{

    @Autowired
    ProductoConsumibleRepository productoConsumibleRepository;

    @Override
    public Page<ProductoConsumible> buscarProductoConsumiblePageable(Pageable pageable) {
        return productoConsumibleRepository.findAll(pageable);
    }


    @Override
    public List<ProductoConsumible> buscarProductoConsumible() {
        return productoConsumibleRepository.findAll();
    }

    @Override
    public Optional<ProductoConsumible> buscarProductoConsumibleId(Integer id) {
        return productoConsumibleRepository.findById(id);
    }

    @Override
    public ProductoConsumible guardarProductoConsumible(ProductoConsumible productoConsumible) {
        return productoConsumibleRepository.save(productoConsumible);
    }

    @Override
    public ProductoConsumible actualizarProductoConsumible(ProductoConsumible productoConsumible) {
        return productoConsumibleRepository.save(productoConsumible);
    }

    @Override
    public boolean borrarProductoConsumible(Integer id) {
        Optional<ProductoConsumible> op = productoConsumibleRepository.findById(id);
        if(op.isPresent()){
            productoConsumibleRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

}
