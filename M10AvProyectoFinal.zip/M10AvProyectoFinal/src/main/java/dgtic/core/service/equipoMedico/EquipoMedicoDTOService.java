package dgtic.core.service.equipoMedico;

import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

public interface EquipoMedicoDTOService {

    public List<EquipoMedicoDTO> getEquiposMedicosList();

    public List<EquipoMedicoDTO> getEquipoMedicoPageable(int page, int size, String dirSort, String sort);

    public Optional<EquipoMedicoDTO> getEquipoMedicoById(int id);

    EquipoMedicoDTO updateEquipoMedico(EquipoMedicoDTO equipoMedicoDTO) throws ParseException, CategoriaNoExisteExcepcion;

    EquipoMedicoDTO createEquipoMedico(EquipoMedicoDTO equipoMedicoDTO) throws ParseException, CategoriaNoExisteExcepcion;

    public boolean deleteEquipoMedico(int id);

    //public List<EquipoMedicoDTO> findEquipoMedicoByPaquete(String paquete);
}

