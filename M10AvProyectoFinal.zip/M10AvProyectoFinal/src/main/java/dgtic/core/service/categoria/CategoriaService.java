package dgtic.core.service.categoria;

import dgtic.core.model.entities.Categoria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface CategoriaService {
    Page<Categoria> buscarCategoriasPageable(Pageable pageable);
    List<Categoria> buscarCategorias();
    Optional<Categoria> buscarCategoriaId(Integer id);
    Optional<Categoria> buscarCategoriaPorNombre(String nombre);
    Categoria guardarCategoria(Categoria categoria);
    Categoria actualizarCategoria(Categoria categoria);
    boolean borrarCategoria(Integer id);
    List<Categoria> buscarCategoriaPatron(String patron);
}
