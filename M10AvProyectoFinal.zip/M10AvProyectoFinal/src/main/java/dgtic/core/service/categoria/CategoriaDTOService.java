package dgtic.core.service.categoria;

import dgtic.core.dto.CategoriaDTO;
import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

public interface CategoriaDTOService {

    public List<CategoriaDTO> getCategoriaList();

    public List<CategoriaDTO> getCategoriaPageable(int page, int size, String dirSort, String sort);

    public Optional<CategoriaDTO> getCategoriaById(int id);

    CategoriaDTO updateCategoria(CategoriaDTO categoriaDTO) throws ParseException, CategoriaNoExisteExcepcion;

    CategoriaDTO createCategoria(CategoriaDTO categoriaDTO) throws ParseException, CategoriaNoExisteExcepcion;

    public boolean deleteCategoria(int id);
}
