package dgtic.core.service.remision;

import dgtic.core.model.entities.Remision;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface RemisionService {

    Page<Remision> buscarRemisionPageable(Pageable pageable);
    List<Remision> buscarRemision();
    Optional<Remision> buscarRemisionId(Integer id);
    Remision guardarRemision(Remision remision);
    Remision actualizarRemision(Remision remision);
    boolean borrarRemision(Integer id);

}
