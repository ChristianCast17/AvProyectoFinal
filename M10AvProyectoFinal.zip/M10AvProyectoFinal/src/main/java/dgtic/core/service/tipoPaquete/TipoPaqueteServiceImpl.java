package dgtic.core.service.tipoPaquete;

import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.TipoPaqueteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TipoPaqueteServiceImpl implements TipoPaqueteService{

    @Autowired
    TipoPaqueteRepository tipoPaqueteRepository;

    @Override
    public Page<TipoPaquete> buscarTipoPaquetePageable(Pageable pageable) {
        return tipoPaqueteRepository.findAll(pageable);
    }

    @Override
    public List<TipoPaquete> buscarTipoPaquete() {
        return tipoPaqueteRepository.findAll();
    }

    @Override
    public Optional<TipoPaquete> buscarTipoPaqueteId(Integer id) {
        return tipoPaqueteRepository.findById(id);
    }

    @Override
    public TipoPaquete guardarTipoPaquete(TipoPaquete tipoPaquete) {
        return tipoPaqueteRepository.save(tipoPaquete);
    }

    @Override
    public TipoPaquete actualizarTipoPaquete(TipoPaquete tipoPaquete) {
        return tipoPaqueteRepository.save(tipoPaquete);
    }

    @Override
    public boolean borrarTipoPaquete(Integer id) {
        Optional<TipoPaquete> op = tipoPaqueteRepository.findById(id);
        if(op.isPresent()){
            tipoPaqueteRepository.delete(op.get());
            return true;
        }else {
            return false;
        }
    }

}
