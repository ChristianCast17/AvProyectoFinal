package dgtic.core.service.equipoMedico;

import dgtic.core.model.entities.Categoria;
import dgtic.core.model.entities.EquipoMedico;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface EquipoMedicoService {

    Page<EquipoMedico> buscarEquipoMedicoPageable(Pageable pageable);
    List<EquipoMedico> buscarEquipoMedico();
    Optional<EquipoMedico> buscarEquipoMedicoId(Integer id);
    EquipoMedico guardarEquipoMedico(EquipoMedico equipoMedico);
    EquipoMedico actualizarEquipoMedico(EquipoMedico equipoMedico);
    boolean borrarEquipoMedico(Integer id);
    List<EquipoMedico> buscarEquipoMedicoPatron(String patron);
}
