package dgtic.core.service.productoConsumible;

import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.model.entities.ProductoConsumible;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ProductoConsumibleService {

    Page<ProductoConsumible> buscarProductoConsumiblePageable(Pageable pageable);

    List<ProductoConsumible> buscarProductoConsumible();
    Optional<ProductoConsumible> buscarProductoConsumibleId(Integer id);
    ProductoConsumible guardarProductoConsumible(ProductoConsumible productoConsumible);
    ProductoConsumible actualizarProductoConsumible(ProductoConsumible productoConsumible);
    boolean borrarProductoConsumible(Integer id);
}
