package dgtic.core.service.categoria;

import dgtic.core.model.entities.Categoria;
import dgtic.core.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaServiceImpl implements CategoriaService{

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public Page<Categoria> buscarCategoriasPageable(Pageable pageable) {
        return categoriaRepository.findAll(pageable);
    }

    @Override
    public List<Categoria> buscarCategorias() {
        return categoriaRepository.findAll();
    }

    @Override
    public Optional<Categoria> buscarCategoriaId(Integer id) {
        return categoriaRepository.findById(id);
    }

    @Override
    public Optional<Categoria> buscarCategoriaPorNombre(String nombre) {
        return Optional.ofNullable(categoriaRepository.findByNombreCategoria(nombre));
    }

    @Override
    public Categoria guardarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    @Override
    public Categoria actualizarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }


    @Override
    public boolean borrarCategoria(Integer id) {
        Optional<Categoria> op = categoriaRepository.findById(id);
        if(op.isPresent()){
            categoriaRepository.delete(op.get());
            return true;
        }else {
            return false;
        }
    }



    @Override
    public List<Categoria> buscarCategoriaPatron(String patron) {
        return categoriaRepository.findByNombreCategoriaContaining(patron);
    }
}
