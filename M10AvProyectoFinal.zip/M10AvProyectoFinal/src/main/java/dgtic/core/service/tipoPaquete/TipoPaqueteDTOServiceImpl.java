package dgtic.core.service.tipoPaquete;

import dgtic.core.dto.CategoriaDTO;
import dgtic.core.dto.TipoPaqueteDTO;
import dgtic.core.model.entities.Categoria;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.CategoriaRepository;
import dgtic.core.repository.TipoPaqueteRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TipoPaqueteDTOServiceImpl implements TipoPaqueteDTOService{

    @Autowired
    TipoPaqueteRepository tipoPaqueteRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<TipoPaqueteDTO> getTipoPaqueteList() {
        List<TipoPaquete> tipoPaquetes = tipoPaqueteRepository.findAll();
        return tipoPaquetes.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<TipoPaqueteDTO> getTipoPaquetePageable(int page, int size, String dirSort, String sort) {
        PageRequest pageRequest = PageRequest.of(page, size, Sort.Direction.fromString(dirSort), sort);
        Page<TipoPaquete> pageResult = tipoPaqueteRepository.findAll(pageRequest);
        //return pageResult.stream().toList();
        return pageResult.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public Optional<TipoPaqueteDTO> getTipoPaqueteById(int id) {
        Optional<TipoPaquete> tipoPaquete = tipoPaqueteRepository.findById(id);
        if (tipoPaquete.isPresent()) {
            TipoPaqueteDTO tipoPaqueteDTO = convertToDTO(tipoPaquete.get());
            return Optional.of(tipoPaqueteDTO);
        } else {
            return Optional.empty();
        }
    }

    @Override
    public TipoPaqueteDTO updateTipoPaquete(TipoPaqueteDTO tipoPaqueteDTO) throws ParseException {
        return convertToDTO(tipoPaqueteRepository.save(this.convertToEntity(tipoPaqueteDTO)));
    }

    @Override
    public TipoPaqueteDTO createTipoPaquete(TipoPaqueteDTO tipoPaqueteDTO) throws ParseException {
        return convertToDTO(tipoPaqueteRepository.save(this.convertToEntity(tipoPaqueteDTO)));
    }

    @Override
    public boolean deleteTipoPaquete(int id) {
        Optional<TipoPaquete> tipoPaquete = tipoPaqueteRepository.findById(id);
        if (tipoPaquete.isPresent()) {
            tipoPaqueteRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    // Convertir de DTO a Entidad
    public TipoPaquete convertToEntity(TipoPaqueteDTO tipoPaqueteDTO) {
        TipoPaquete tipoPaquete = modelMapper.map(tipoPaqueteDTO, TipoPaquete.class);
        tipoPaquete.setIdTipoPaquete(tipoPaqueteDTO.getIdTipoPaquete());
        tipoPaquete.setNombrePaquete(tipoPaqueteDTO.getNombrePaquete());
        return tipoPaquete;
    }

    // Convertir de Entidad a DTO
    public TipoPaqueteDTO convertToDTO(TipoPaquete tipoPaquete) {
        TipoPaqueteDTO tipoPaqueteDTO = modelMapper.map(tipoPaquete, TipoPaqueteDTO.class);
        tipoPaqueteDTO.setIdTipoPaquete(tipoPaquete.getIdTipoPaquete());
        tipoPaqueteDTO.setNombrePaquete(tipoPaquete.getNombrePaquete());
        return tipoPaqueteDTO;
    }

}
