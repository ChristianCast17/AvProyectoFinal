package dgtic.core.service.categoria;

import dgtic.core.dto.CategoriaDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;
import dgtic.core.model.entities.Categoria;
import dgtic.core.repository.CategoriaRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoriaDTOServiceImpl implements CategoriaDTOService{

    @Autowired
    CategoriaRepository categoriaRepository;

    @Autowired
    private  ModelMapper modelMapper;

    @Override
    public List<CategoriaDTO> getCategoriaList() {
        List<Categoria> categorias = categoriaRepository.findAll();
        return categorias.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<CategoriaDTO> getCategoriaPageable(int page, int size, String dirSort, String sort) {
        PageRequest pageRequest = PageRequest.of(page, size, Sort.Direction.fromString(dirSort), sort);
        Page<Categoria> pageResult = categoriaRepository.findAll(pageRequest);
        //return pageResult.stream().toList();
        return pageResult.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public Optional<CategoriaDTO> getCategoriaById(int id) {
        Optional<Categoria> categoria = categoriaRepository.findById(id);
        if (categoria.isPresent()) {
            CategoriaDTO categoriaDTO = convertToDTO(categoria.get());
            return Optional.of(categoriaDTO);
        } else {
            return Optional.empty();
        }
    }

    @Override
    public CategoriaDTO updateCategoria(CategoriaDTO categoriaDTO) throws ParseException, CategoriaNoExisteExcepcion {
        return convertToDTO(categoriaRepository.save(this.convertToEntity(categoriaDTO)));
    }

    @Override
    public CategoriaDTO createCategoria(CategoriaDTO categoriaDTO) throws ParseException, CategoriaNoExisteExcepcion {
        return convertToDTO(categoriaRepository.save(this.convertToEntity(categoriaDTO)));
    }

    @Override
    public boolean deleteCategoria(int id) {
        Optional<Categoria> categoria = categoriaRepository.findById(id);
        if (categoria.isPresent()) {
            categoriaRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    // Convertir de DTO a Entidad
    public Categoria convertToEntity(CategoriaDTO categoriaDTO) {
        Categoria categoria = modelMapper.map(categoriaDTO, Categoria.class);
        categoria.setIdCategoria(categoriaDTO.getIdCategoria());
        categoria.setNombreCategoria(categoriaDTO.getNombreCategoria());
        return categoria;
    }

    // Convertir de Entidad a DTO
    public CategoriaDTO convertToDTO(Categoria categoria) {
        CategoriaDTO categoriaDTO = modelMapper.map(categoria, CategoriaDTO.class);
        categoriaDTO.setIdCategoria(categoria.getIdCategoria());
        categoriaDTO.setNombreCategoria(categoria.getNombreCategoria());
        return categoriaDTO;
    }
}
