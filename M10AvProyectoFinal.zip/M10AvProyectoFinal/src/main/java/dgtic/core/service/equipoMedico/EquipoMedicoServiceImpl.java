package dgtic.core.service.equipoMedico;

import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.repository.EquipoMedicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EquipoMedicoServiceImpl implements EquipoMedicoService{

    @Autowired
    EquipoMedicoRepository equipoMedicoRepository;

    @Override
    public Page<EquipoMedico> buscarEquipoMedicoPageable(Pageable pageable) {
        return equipoMedicoRepository.findAll(pageable);
    }

    @Override
    public List<EquipoMedico> buscarEquipoMedico() {
        return equipoMedicoRepository.findAll();
    }

    @Override
    public Optional<EquipoMedico> buscarEquipoMedicoId(Integer id) {
        return equipoMedicoRepository.findById(id);
    }

    @Override
    public EquipoMedico guardarEquipoMedico(EquipoMedico equipoMedico) {
        return equipoMedicoRepository.save(equipoMedico);
    }

    @Override
    public EquipoMedico actualizarEquipoMedico(EquipoMedico equipoMedico) {
        return equipoMedicoRepository.save(equipoMedico);
    }

    @Override
    public boolean borrarEquipoMedico(Integer id) {
        Optional<EquipoMedico> op = equipoMedicoRepository.findById(id);
        if (op.isPresent()){
            equipoMedicoRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public List<EquipoMedico> buscarEquipoMedicoPatron(String patron) {
        return null;
    }
}
