package dgtic.core.service.equipoMedico;

import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;
import dgtic.core.model.entities.Categoria;
import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.repository.CategoriaRepository;
import dgtic.core.repository.EquipoMedicoRepository;
import dgtic.core.repository.TipoPaqueteRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EquipoMedicoDTOServiceImpl implements EquipoMedicoDTOService {

    @Autowired
    private EquipoMedicoRepository equipoMedicoRepository;
    @Autowired
    private CategoriaRepository categoriaRepository;
    @Autowired
    private TipoPaqueteRepository tipoPaqueteRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<EquipoMedicoDTO> getEquiposMedicosList() {
        List<EquipoMedico> equiposMedicos = equipoMedicoRepository.findAll();
        return equiposMedicos.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<EquipoMedicoDTO> getEquipoMedicoPageable(int page, int size, String dirSort, String sort) {
        PageRequest pageRequest = PageRequest.of(page, size, Sort.Direction.fromString(dirSort), sort);
        Page<EquipoMedico> pageResult = equipoMedicoRepository.findAll(pageRequest);
        //return pageResult.stream().toList();
        return pageResult.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public Optional<EquipoMedicoDTO> getEquipoMedicoById(int id) {
        Optional<EquipoMedico> equipoMedico = equipoMedicoRepository.findById(id);
        if (equipoMedico.isPresent()) {
            EquipoMedicoDTO equipoMedicoDTO = convertToDTO(equipoMedico.get());
            return Optional.of(equipoMedicoDTO);
        } else {
            return Optional.empty();
        }
    }

    @Override
    public EquipoMedicoDTO updateEquipoMedico(EquipoMedicoDTO equipoMedicoDTO) throws ParseException, CategoriaNoExisteExcepcion {
        return convertToDTO(equipoMedicoRepository.save(this.convertToEntity(equipoMedicoDTO)));
    }

    @Override
    public EquipoMedicoDTO createEquipoMedico(EquipoMedicoDTO equipoMedicoDTO) throws ParseException, CategoriaNoExisteExcepcion {
        return convertToDTO(equipoMedicoRepository.save(this.convertToEntity(equipoMedicoDTO)));
    }

    @Override
    public boolean deleteEquipoMedico(int id) {
        Optional<EquipoMedico> equipoMedico = equipoMedicoRepository.findById(id);
        if (equipoMedico.isPresent()) {
            equipoMedicoRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

//    public EquipoMedico convertToEntity(EquipoMedicoDTO equipoMedicoDTO) {
//
//        // Inicializar ModelMapper
//        ModelMapper modelMapper = new ModelMapper();
//        EquipoMedico equipoMedico = modelMapper.map(equipoMedicoDTO, EquipoMedico.class);
//
//        // Configurar el mapeo manual de Categoria
//        if (equipoMedicoDTO.getCategoria() != 0) {
//            Categoria categoria = categoriaRepository.findById(equipoMedicoDTO.getCategoria())
//                    .orElseThrow(() -> new IllegalArgumentException("Categoría no encontrada"));
//            equipoMedico.setCategoria(categoria);
//        }
//
//        // Configurar el mapeo manual de Paquetes
//        if (equipoMedicoDTO.getPaquetes() != null && !equipoMedicoDTO.getPaquetes().isEmpty()) {
//            List<TipoPaquete> paquetes = Arrays.stream(equipoMedicoDTO.getPaquetes().split(","))
//                    .map(String::trim)
//                    .map(nombrePaquete -> tipoPaqueteRepository.findByNombrePaquete(nombrePaquete))
//                    .collect(Collectors.toList());
//            equipoMedico.setPaquetes(paquetes);
//        }
//        return equipoMedico;
//    }
//
//    public EquipoMedicoDTO convertToDTO(EquipoMedico equipoMedico) {
//
//        // Inicializar ModelMapper
//        ModelMapper modelMapper = new ModelMapper();
//        EquipoMedicoDTO equipoMedicoDTO = modelMapper.map(equipoMedico, EquipoMedicoDTO.class);
//
//        // Configurar manualmente la categoría
//        if (equipoMedico.getCategoria() != null) {
//            equipoMedicoDTO.setCategoria(equipoMedico.getCategoria().getIdCategoria());
//        }
//
//        // Configurar manualmente los paquetes
//        if (equipoMedico.getPaquetes() != null && !equipoMedico.getPaquetes().isEmpty()) {
//            String paquetes = equipoMedico.getPaquetes().stream()
//                    .map(TipoPaquete::getNombrePaquete)
//                    .collect(Collectors.joining(", "));
//            equipoMedicoDTO.setPaquetes(paquetes);
//        }
//
//        return equipoMedicoDTO;
//    }


    private EquipoMedicoDTO convertToDTO(EquipoMedico equipoMedico) {
        EquipoMedicoDTO equipoMedicoDTO = modelMapper.map(equipoMedico, EquipoMedicoDTO.class);
        System.out.println("EquipoMedico2EquipoMedicoDTO: " + equipoMedicoDTO.toString());
        if (equipoMedico.getCategoria() != null) {
            equipoMedicoDTO.setCategoria(equipoMedico.getCategoria().getNombreCategoria());
        }
        if (equipoMedico.getPaquetes() != null) {
            equipoMedicoDTO.setPaquetes(equipoMedico.getPaquetes().stream().map(TipoPaquete::getNombrePaquete) // Obtener solo los nombres de los paquetes
                    .collect(Collectors.joining(", "))); // Convertir a un String separado por comas
        }
        return equipoMedicoDTO;
    }

    private EquipoMedico convertToEntity(EquipoMedicoDTO equipoMedicoDTO) throws ParseException, CategoriaNoExisteExcepcion {
        EquipoMedico equipoMedico = modelMapper.map(equipoMedicoDTO, EquipoMedico.class);
        System.out.println("EquipoDTO2Equipo: " + equipoMedico.toString());
        if (equipoMedicoDTO.getCategoria() != null) {
            Categoria categoria = categoriaRepository.findByNombreCategoria(equipoMedicoDTO.getCategoria());
            equipoMedico.setCategoria(categoria);
            if (categoria == null) {
                //Lanzar una exception
                throw new CategoriaNoExisteExcepcion("La categoria no existe");
            } else {
                equipoMedico.setCategoria(categoria);
            }
        }
        // Manejo de la relación con TipoPaquete
        if (equipoMedicoDTO.getPaquetes() != null && !equipoMedicoDTO.getPaquetes().isBlank()) {
            // Suponemos que los paquetes son un String separados por comas
            List<TipoPaquete> paquetes = Arrays.stream(equipoMedicoDTO.getPaquetes().split(","))
                    .map(String::trim) // Elimina espacios adicionales
                    .map(nombrePaquete -> tipoPaqueteRepository.findByNombrePaquete(nombrePaquete))
                    .filter(Objects::nonNull) // Filtra paquetes que no existan
                    .collect(Collectors.toList());

            if (paquetes.isEmpty()) {
                throw new IllegalArgumentException("No se encontraron paquetes válidos en la base de datos.");
            }
            equipoMedico.setPaquetes(paquetes);
        }
        // Devolver la entidad convertida
        return equipoMedico;
    }

}
