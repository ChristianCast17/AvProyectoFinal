package dgtic.core.service.remision;

import dgtic.core.model.entities.Remision;
import dgtic.core.repository.RemisionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RemisionServiceImpl implements RemisionService{

    @Autowired
    RemisionRepository remisionRepository;

    @Override
    public Page<Remision> buscarRemisionPageable(Pageable pageable) {
        return remisionRepository.findAll(pageable);
    }

    @Override
    public List<Remision> buscarRemision() {
        return remisionRepository.findAll();
    }

    @Override
    public Optional<Remision> buscarRemisionId(Integer id) {
        return remisionRepository.findById(id);
    }

    @Override
    public Remision guardarRemision(Remision remision) {
        return remisionRepository.save(remision);
    }

    @Override
    public Remision actualizarRemision(Remision remision) {
        return remisionRepository.save(remision);
    }

    @Override
    public boolean borrarRemision(Integer id) {
        Optional<Remision> op = remisionRepository.findById(id);
        if (op.isEmpty()){
            remisionRepository.delete(op.get());
            return true;
        }else {
            return false;
        }
    }

}
