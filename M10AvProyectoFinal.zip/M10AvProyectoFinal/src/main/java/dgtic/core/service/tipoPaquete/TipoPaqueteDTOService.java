package dgtic.core.service.tipoPaquete;

import dgtic.core.dto.CategoriaDTO;
import dgtic.core.dto.TipoPaqueteDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

public interface TipoPaqueteDTOService {

    public List<TipoPaqueteDTO> getTipoPaqueteList();

    public List<TipoPaqueteDTO> getTipoPaquetePageable(int page, int size, String dirSort, String sort);

    public Optional<TipoPaqueteDTO> getTipoPaqueteById(int id);

    TipoPaqueteDTO updateTipoPaquete(TipoPaqueteDTO tipoPaqueteDTO) throws ParseException;

    TipoPaqueteDTO createTipoPaquete(TipoPaqueteDTO tipoPaqueteDTO) throws ParseException;

    public boolean deleteTipoPaquete(int id);
}
