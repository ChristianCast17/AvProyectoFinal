package dgtic.core.service.tipoPaquete;

import dgtic.core.model.entities.TipoPaquete;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface TipoPaqueteService {

    Page<TipoPaquete> buscarTipoPaquetePageable(Pageable pageable);
    List<TipoPaquete> buscarTipoPaquete();
    Optional<TipoPaquete> buscarTipoPaqueteId(Integer id);
    TipoPaquete guardarTipoPaquete(TipoPaquete tipoPaquete);
    TipoPaquete actualizarTipoPaquete(TipoPaquete tipoPaquete);
    boolean borrarTipoPaquete(Integer id);

}
