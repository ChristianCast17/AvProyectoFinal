package dgtic.core.controller.productoConsumible;

import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;
import dgtic.core.model.entities.ProductoConsumible;
import dgtic.core.service.equipoMedico.EquipoMedicoDTOService;
import dgtic.core.service.productoConsumible.ProductoConsumibleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v2/productosConsumibles", produces = MediaType.APPLICATION_JSON_VALUE)
public class ProductoConsumibleController {

    @Autowired
    private ProductoConsumibleService productoConsumibleService;

    // Obtener todos
    @GetMapping(path = "/")
    public List<ProductoConsumible> getAll() {
        return productoConsumibleService.buscarProductoConsumible();
    }

    // Obtener por matrícula
    @GetMapping(path = "/{id}")
    public ResponseEntity<ProductoConsumible> getById(@PathVariable int id) {
        Optional<ProductoConsumible> productoConsumible = productoConsumibleService.buscarProductoConsumibleId(id);
        if (productoConsumible.isPresent()) {
            return ResponseEntity.ok(productoConsumible.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping(path = "/")
    public ResponseEntity<ProductoConsumible> createProductoConsumible(
            @Valid @RequestBody ProductoConsumible productoConsumible) throws ParseException, URISyntaxException, CategoriaNoExisteExcepcion {
        ProductoConsumible productoNuevo = productoConsumibleService.guardarProductoConsumible(productoConsumible);
        URI location = new URI("/api/v2/productosCosumibles/" + productoNuevo.getIdProductoConsumible());
        return ResponseEntity.created(location).body(productoNuevo);
    }

    @PutMapping(path = "/{id}")
    public ResponseEntity<ProductoConsumible> updateProductoConsumible(@PathVariable int id, @RequestBody ProductoConsumible producto) throws ParseException, CategoriaNoExisteExcepcion {
        producto.setIdProductoConsumible(id);
        return ResponseEntity.ok(productoConsumibleService.actualizarProductoConsumible(producto));
    }

    @PatchMapping(path = "/{id}")
    public ResponseEntity<ProductoConsumible> updatePartialProducto(@PathVariable int id, @RequestBody ProductoConsumible producto) throws ParseException, CategoriaNoExisteExcepcion {
        Optional<ProductoConsumible> productoDB = productoConsumibleService.buscarProductoConsumibleId(id);
        if (productoDB.isPresent()) {
            ProductoConsumible modificable = productoDB.get();
            if (producto.getNombreProducto() != null) modificable.setNombreProducto(producto.getNombreProducto());
            if (producto.getExistencias() != 0) modificable.setExistencias(producto.getExistencias());
            if (producto.getDescripcion() != null) modificable.setDescripcion(producto.getDescripcion());
            //if (producto.getPaquetes() != null) modificable.setPaquetes(producto.getPaquetes());
            return ResponseEntity.ok(productoConsumibleService.actualizarProductoConsumible(modificable));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<?> deleteProducto(@PathVariable int id) {
        if (productoConsumibleService.borrarProductoConsumible(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }


}
