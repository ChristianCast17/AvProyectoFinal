package dgtic.core.controller.categoria;

import dgtic.core.model.entities.Categoria;
import dgtic.core.service.categoria.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/categorias",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class CategoriaController {

    @Autowired
    private CategoriaService categoriaService;

    @GetMapping(path = "/")
    public ResponseEntity<List<Categoria>> getAll() {
        return ResponseEntity.ok(categoriaService.buscarCategorias());
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<Categoria> getById(@PathVariable("id") int id) {
        Optional<Categoria> categoria = categoriaService.buscarCategoriaId(id);
        if (categoria.isPresent()) {
            return ResponseEntity.ok(categoria.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @PostMapping(path = "/")
    public ResponseEntity<Categoria> createCategoria(@RequestBody Categoria categoria) throws URISyntaxException {
        Categoria categoriaNueva = categoriaService.guardarCategoria(categoria);
        URI location = new URI("/api/categorias/" + categoriaNueva.getIdCategoria());
        return ResponseEntity.created(location).body(categoriaNueva);
    }

    @PutMapping(path = "/{id}")
    public ResponseEntity<Categoria> updateFullCategoria(@RequestBody Categoria categoria, @PathVariable("id") int id) throws URISyntaxException {
        Optional<Categoria> categoriaDB = categoriaService.buscarCategoriaId(id);
        if (categoriaDB.isPresent()) {
            categoria.setIdCategoria(categoriaDB.get().getIdCategoria());
            Optional<Categoria> catOp = categoriaService.buscarCategoriaPorNombre(categoria.getNombreCategoria());
            if (catOp.isPresent()){
                return ResponseEntity.badRequest().build();
            }
            return ResponseEntity.ok(categoriaService.actualizarCategoria(categoria));
        } else {
            Categoria categoriaNueva = categoriaService.guardarCategoria(categoria);
            URI location = new URI("/api/categorias/" + categoriaNueva.getIdCategoria());
            return ResponseEntity.created(location).body(categoriaNueva);
        }
    }

    @PatchMapping(path = "/{id}")
    public ResponseEntity<Categoria> updatePartialCategoria(@RequestBody Categoria categoria, @PathVariable("id") int id) throws URISyntaxException {
        Optional<Categoria> categoriaDB = categoriaService.buscarCategoriaId(id);
        if (categoriaDB.isPresent()) {
            Categoria categoriaToUpdate = categoriaDB.get();
            if (categoria.getNombreCategoria() != null) {
                categoriaToUpdate.setNombreCategoria(categoria.getNombreCategoria());
            }
            return ResponseEntity.ok(categoriaService.actualizarCategoria(categoriaToUpdate));
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping(path = "/{id}")
    public ResponseEntity<Boolean> deleteAlumno(@PathVariable("id") int id) {
        if (categoriaService.borrarCategoria(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
