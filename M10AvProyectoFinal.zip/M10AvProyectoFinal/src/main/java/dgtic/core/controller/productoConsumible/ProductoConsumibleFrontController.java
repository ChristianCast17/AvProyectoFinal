package dgtic.core.controller.productoConsumible;

import dgtic.core.model.entities.ProductoConsumible;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.service.productoConsumible.ProductoConsumibleService;
import dgtic.core.service.tipoPaquete.TipoPaqueteService;
import dgtic.core.util.RenderPagina;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "productoConsumible")
public class ProductoConsumibleFrontController {

    @Autowired
    ProductoConsumibleService productoConsumibleService;

    @Autowired
    TipoPaqueteService tipoPaqueteService;

    @GetMapping("alta-productoConsumible")
    public String altaProductoConsumible(Model model ){

        ProductoConsumible productoConsumible = new ProductoConsumible();
        List<TipoPaquete> selectTipo = tipoPaqueteService.buscarTipoPaquete();

        model.addAttribute("contenido", "Alta De Producto Consumible");
        model.addAttribute("productoConsumible", productoConsumible);
        model.addAttribute("selectTipo", selectTipo);

        return "productoConsumible/alta-productoConsumible";
    }

    @PostMapping("salvar-productoConsumible")
    public String salvarProductoConsumible(@Valid @ModelAttribute("productoConsumible") ProductoConsumible productoConsumible
            , BindingResult result, Model model,
                                     RedirectAttributes flash){
        System.out.println(productoConsumible);
        List<TipoPaquete> selectTipo = tipoPaqueteService.buscarTipoPaquete();

        if(result.hasErrors()) {
            model.addAttribute("contenido", "Error en el nombre, no debe ser vacío");
            return "productoConsumible/alta-productoConsumible";
        }
        productoConsumibleService.guardarProductoConsumible(productoConsumible);
        model.addAttribute("success","Se almaceno el Producto Consumible con éxito");
        model.addAttribute("productoConsumible",productoConsumible);
        model.addAttribute("selectTipo", selectTipo);
        return "productoConsumible/alta-productoConsumible";
    }

    @GetMapping("lista-productoConsumible")
    public String listaProductoConsumible(@RequestParam(name="page",defaultValue = "0")int page, Model model){
        Pageable pageable= PageRequest.of(page,2);
        Page<ProductoConsumible> productoConsumible = productoConsumibleService.buscarProductoConsumiblePageable(pageable);
        RenderPagina<ProductoConsumible> renderPagina = new RenderPagina<>("lista-productoConsumible",productoConsumible);
        model.addAttribute("producto",productoConsumible);
        model.addAttribute("page",renderPagina);
        model.addAttribute("contenido","Lista de Productos Consumibles");
        return "productoConsumible/lista-productoConsumible";
    }

    @GetMapping("modificar-productoConsumible/{id}")
    public String modificarProductoConsumible(@PathVariable Integer id, Model model) {
        Optional<ProductoConsumible> op = productoConsumibleService.buscarProductoConsumibleId(id);
        ProductoConsumible productoConsumible = op.get();
        List<TipoPaquete> selectTipo = tipoPaqueteService.buscarTipoPaquete();
        model.addAttribute("productoConsumible", productoConsumible);
        model.addAttribute("contenido", "Modificar Producto Consumible");
        model.addAttribute("selectTipo", selectTipo);
        return "productoConsumible/alta-productoConsumible";
    }


    @GetMapping("eliminar-productoConsumible/{id}")
    public String eliminarProductoConsumible(@PathVariable Integer id, RedirectAttributes flash) {
        productoConsumibleService.borrarProductoConsumible(id);
        flash.addFlashAttribute("success", "Producto Consumible Eliminado");
        return "redirect:/productoConsumible/lista-productoConsumible";
    }

}
