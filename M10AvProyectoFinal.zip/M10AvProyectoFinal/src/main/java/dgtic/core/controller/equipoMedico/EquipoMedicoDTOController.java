package dgtic.core.controller.equipoMedico;

import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.exception.CategoriaNoExisteExcepcion;
import dgtic.core.service.equipoMedico.EquipoMedicoDTOService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v2/equiposMedicos", produces = MediaType.APPLICATION_JSON_VALUE)
public class EquipoMedicoDTOController {

        @Autowired
        private EquipoMedicoDTOService equipoMedicoDTOService;

        // Obtener todos
        @GetMapping(path = "/")
        public List<EquipoMedicoDTO> getAllDTO() {
            return equipoMedicoDTOService.getEquiposMedicosList();
        }

        // Obtener por matrícula
        @GetMapping(path = "/{id}")
        public ResponseEntity<EquipoMedicoDTO> getByIdDTO(@PathVariable int id) {
            Optional<EquipoMedicoDTO> equipoMedicoDTO = equipoMedicoDTOService.getEquipoMedicoById(id);
            if (equipoMedicoDTO.isPresent()) {
                return ResponseEntity.ok(equipoMedicoDTO.get());
            } else {
                return ResponseEntity.notFound().build();
            }
        }

        @PostMapping(path = "/")
        public ResponseEntity<EquipoMedicoDTO> createEquipoMedicoDTO(
                @Valid @RequestBody EquipoMedicoDTO equipoDTO) throws ParseException, URISyntaxException, CategoriaNoExisteExcepcion {
            EquipoMedicoDTO equipoMedicoDTO = equipoMedicoDTOService.createEquipoMedico(equipoDTO);
            return ResponseEntity.ok(equipoMedicoDTO);
        }

        @PutMapping(path = "/{id}")
        public ResponseEntity<EquipoMedicoDTO> updateEquipoDTO(@PathVariable int id, @RequestBody EquipoMedicoDTO equipo) throws ParseException, CategoriaNoExisteExcepcion {
            equipo.setId(id);
            return ResponseEntity.ok(equipoMedicoDTOService.updateEquipoMedico(equipo));
        }

        @PatchMapping(path = "/{id}")
        public ResponseEntity<EquipoMedicoDTO> updatePartialEquipoDTO(@PathVariable int id, @RequestBody EquipoMedicoDTO equipo) throws ParseException, CategoriaNoExisteExcepcion {
            Optional<EquipoMedicoDTO> equipoDB = equipoMedicoDTOService.getEquipoMedicoById(id);
            if (equipoDB.isPresent()) {
                EquipoMedicoDTO modificable = equipoDB.get();
                if (equipo.getNombreEquipo() != null) modificable.setNombreEquipo(equipo.getNombreEquipo());
                if (equipo.getExistencias() != 0) modificable.setExistencias(equipo.getExistencias());
                if (equipo.getCategoria() != null) modificable.setCategoria(equipo.getCategoria());
                if (equipo.getPaquetes() != null) modificable.setPaquetes(equipo.getPaquetes());
                return ResponseEntity.ok(equipoMedicoDTOService.updateEquipoMedico(modificable));
            } else {
                return ResponseEntity.notFound().build();
            }
        }

        @DeleteMapping(path = "/{id}")
        public ResponseEntity<?> deleteEquipo(@PathVariable int id) {
            if (equipoMedicoDTOService.deleteEquipoMedico(id)) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.notFound().build();
            }
        }


        // /api/v2/alumnos/paginado?page=0&size=2&dir=asc&sort=nombre
        @GetMapping(path = "/paginado")
        public ResponseEntity<List<EquipoMedicoDTO>> getPaginadoAlumnoDTO(
                @RequestParam(defaultValue = "0") int page,
                @RequestParam(defaultValue = "2") int size,
                @RequestParam(defaultValue = "asc") String dir,
                @RequestParam(defaultValue = "id") String sort
        ) {
            return ResponseEntity.ok(equipoMedicoDTOService.getEquipoMedicoPageable(page, size, dir, sort));
        }

        @ExceptionHandler(HttpMessageNotReadableException.class)
        public ResponseEntity<Map<String, String>> errorFormatoDeCliente(
                HttpMessageNotReadableException ex){
            HashMap<String, String> detalles = new HashMap<>();
            detalles.put("mensaje","el formato de los datos es incorrecto");
            detalles.put("detalle", ex.getMessage());
            detalles.put("timestamp", LocalDateTime.now().toString());
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(detalles);
        }

        @ExceptionHandler(MethodArgumentNotValidException.class)
        public ResponseEntity<Map<String, Object>> tratamientoValidacion(
                MethodArgumentNotValidException ex){

            HashMap<String, Object> detalles = new HashMap<>();
            detalles.put("mensaje", "Eror de validacion de campos. Revisa la entrada" );
            detalles.put("statusCode", ex.getStatusCode().toString());
            detalles.put("timestap", LocalDateTime.now().toString());
            HashMap<String, String> detalleCampos = new HashMap<>();

            int i = 1;
            for (FieldError campoError : ex.getBindingResult().getFieldErrors()){
                detalleCampos.put(campoError.getField()+ i++ ,campoError.getDefaultMessage());
            }
            detalles.put("errores",detalleCampos);
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(detalles);
        }

        @GetMapping(path = "/ping/{veces}")
        public ResponseEntity<String> ping(@PathVariable int veces){
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < veces; i++) {
                str.append("\n TTL " + i );
            }
            return ResponseEntity.status(HttpStatus.OK)
                    .contentType(MediaType.TEXT_PLAIN)
                    .body(str.toString());
        }

}
