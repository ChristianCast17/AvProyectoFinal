package dgtic.core.controller.tipoPaquete;


import dgtic.core.model.entities.TipoPaquete;

import dgtic.core.service.tipoPaquete.TipoPaqueteService;
import dgtic.core.util.RenderPagina;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping(value = "tipoPaquete")
public class TipoPaqueteFrontController {

    @Autowired
    TipoPaqueteService tipoPaqueteService;

    @GetMapping("alta-tipoPaquete")
    public String altaTipoPaquete(Model model ){
        TipoPaquete tipoPaquete = new TipoPaquete();

        model.addAttribute("contenido", "Alta De un Paquete");
        model.addAttribute("tipoPaquete", tipoPaquete);
        return "tipoPaquete/alta-tipoPaquete";
    }

    @PostMapping("salvar-tipoPaquete")
    public String salvarTipoPaquete(@Valid @ModelAttribute("tipoPaquete") TipoPaquete tipoPaquete
            , BindingResult result, Model model,
                                     RedirectAttributes flash){
        System.out.println(tipoPaquete);
        if(result.hasErrors()) {
            model.addAttribute("contenido", "Error en el nombre, no debe ser vacío");
            return "tipoPaquete/alta-tipoPaquete";
        }
        tipoPaqueteService.guardarTipoPaquete(tipoPaquete);
        model.addAttribute("success","Se almaceno el Paquete con éxito");
        model.addAttribute("tipoPaquete",tipoPaquete);
        return "tipoPaquete/alta-tipoPaquete";
    }

    @GetMapping("lista-tipoPaquete")
    public String listaTipoPaquete(@RequestParam(name="page",defaultValue = "0")int page, Model model){
        Pageable pageable= PageRequest.of(page,2);
        Page<TipoPaquete> paquetes = tipoPaqueteService.buscarTipoPaquetePageable(pageable);
        RenderPagina<TipoPaquete> renderPagina = new RenderPagina<>("lista-tipoPaquete", paquetes);
        model.addAttribute("paquete",paquetes);
        model.addAttribute("page",renderPagina);
        model.addAttribute("contenido","Lista de Paquetes");
        return "tipoPaquete/lista-tipoPaquete";
    }

    @GetMapping("modificar-tipoPaquete/{id}")
    public String modificarEquipoMedico(@PathVariable Integer id, Model model) {
        Optional<TipoPaquete> op = tipoPaqueteService.buscarTipoPaqueteId(id);
        TipoPaquete tipoPaquete = op.get();
        model.addAttribute("tipoPaquete", tipoPaquete);
        model.addAttribute("contenido", "Modificar Tipo Paquete");
        return "tipoPaquete/alta-tipoPaquete";
    }


    @GetMapping("eliminar-tipoPaquete/{id}")
    public String eliminarTipoPaquete(@PathVariable Integer id, RedirectAttributes flash) {
        tipoPaqueteService.borrarTipoPaquete(id);
        flash.addFlashAttribute("success", "Paquete Eliminado");
        return "redirect:/tipoPaquete/lista-tipoPaquete";
    }

}

