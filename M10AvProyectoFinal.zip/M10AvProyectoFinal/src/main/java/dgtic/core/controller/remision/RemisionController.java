package dgtic.core.controller.remision;


import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.Remision;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.service.remision.RemisionService;
import dgtic.core.service.tipoPaquete.TipoPaqueteService;
import dgtic.core.util.RenderPagina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "remision")
public class RemisionController {

    @Autowired
    RemisionService remisionService;

    @Autowired
    TipoPaqueteService tipoPaqueteService;

    @GetMapping("alta-remision")
    public String altaRemision(Model model ){
        Remision remision = new Remision();
        List<TipoPaquete> selectTipo = tipoPaqueteService.buscarTipoPaquete();

        model.addAttribute("contenido", "Alta De Remision");
        model.addAttribute("remision", remision);
        model.addAttribute("selectTipo", selectTipo);

        return "remision/alta-remision";
    }
}