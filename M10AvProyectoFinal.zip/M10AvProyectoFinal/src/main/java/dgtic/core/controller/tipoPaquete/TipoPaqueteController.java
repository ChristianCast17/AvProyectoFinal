package dgtic.core.controller.tipoPaquete;

import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.service.tipoPaquete.TipoPaqueteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/tipoPaquete",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class TipoPaqueteController {

    @Autowired
    private TipoPaqueteService tipoPaqueteService;

    @GetMapping(path = "/")
    public ResponseEntity<List<TipoPaquete>> getAll() {
        return ResponseEntity.ok(tipoPaqueteService.buscarTipoPaquete());
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<TipoPaquete> getById(@PathVariable("id") int id) {
        Optional<TipoPaquete> tipoPaquete = tipoPaqueteService.buscarTipoPaqueteId(id);
        if (tipoPaquete.isPresent()) {
            return ResponseEntity.ok(tipoPaquete.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping(path = "/")
    public ResponseEntity<TipoPaquete> createTipoPaquete(@RequestBody TipoPaquete tipoPaquete) throws URISyntaxException {
        TipoPaquete tipoPaqueteNuevo = tipoPaqueteService.guardarTipoPaquete(tipoPaquete);
        URI location = new URI("/api/tipoPaquetes/" + tipoPaqueteNuevo.getIdTipoPaquete());
        return ResponseEntity.created(location).body(tipoPaqueteNuevo);
    }

    @PutMapping(path = "/{id}")
    public ResponseEntity<TipoPaquete> updateFullTipoPaquete(@RequestBody TipoPaquete tipoPaquete, @PathVariable("id") int id) throws URISyntaxException {
        Optional<TipoPaquete> tipoPaqueteDB = tipoPaqueteService.buscarTipoPaqueteId(id);
        if (tipoPaqueteDB.isPresent()) {
            tipoPaquete.setIdTipoPaquete(tipoPaqueteDB.get().getIdTipoPaquete());
            return ResponseEntity.ok(tipoPaqueteService.actualizarTipoPaquete(tipoPaquete));
        } else {
            TipoPaquete tipoPaqueteNuevo = tipoPaqueteService.guardarTipoPaquete(tipoPaquete);
            URI location = new URI("/api/categorias/" + tipoPaqueteNuevo.getIdTipoPaquete());
            return ResponseEntity.created(location).body(tipoPaqueteNuevo);
        }
    }

    @PatchMapping(path = "/{id}")
    public ResponseEntity<TipoPaquete> updatePartialTipoPaquete(@RequestBody TipoPaquete tipoPaquete, @PathVariable("id") int id) throws URISyntaxException {
        Optional<TipoPaquete> tipoPaqueteDB = tipoPaqueteService.buscarTipoPaqueteId(id);
        if (tipoPaqueteDB.isPresent()) {
            TipoPaquete tipoPaqueteToUpdate = tipoPaqueteDB.get();
            if (tipoPaquete.getNombrePaquete() != null) {
                tipoPaqueteToUpdate.setNombrePaquete(tipoPaquete.getNombrePaquete());
            }
            return ResponseEntity.ok(tipoPaqueteService.actualizarTipoPaquete(tipoPaqueteToUpdate));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<Boolean> deleteAlumno(@PathVariable("id") int id) {
        if (tipoPaqueteService.borrarTipoPaquete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
