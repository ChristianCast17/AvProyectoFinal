package dgtic.core.exception;

public class CategoriaNoExisteExcepcion extends Exception{

    public CategoriaNoExisteExcepcion(String message){
        super(message);
    }
}
