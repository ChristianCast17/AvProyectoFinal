package dgtic.core.clienteweb.services;

import dgtic.core.dto.EquipoMedicoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class EquipoMedicoWebClientService {

    @Autowired
    private WebClient webClient;

    public List<EquipoMedicoDTO> getAll(){
        Mono<List<EquipoMedicoDTO>> equiposMono = webClient.get()
                .uri("/")
                .retrieve()
                .bodyToFlux(EquipoMedicoDTO.class)
                .collectList();
        List<EquipoMedicoDTO> equipos = equiposMono.block();
        return equipos;
    }

    public EquipoMedicoDTO getEquipoById(Integer id){
        Mono<EquipoMedicoDTO> equipoMedicoDTOMono = webClient.get()
                .uri("/{id}", id)
                .retrieve()
                .bodyToMono(EquipoMedicoDTO.class);
        EquipoMedicoDTO equipoMedicoDTO = equipoMedicoDTOMono.block();
        return equipoMedicoDTO;
    }

    public EquipoMedicoDTO actualizaEquipo(EquipoMedicoDTO equipoMedicoDTO){
        return webClient.put().uri("/{id}", equipoMedicoDTO.getId())
                .bodyValue(equipoMedicoDTO)
                .retrieve()
                .bodyToMono(EquipoMedicoDTO.class)
                .block();
    }

    public EquipoMedicoDTO crearEquipo(EquipoMedicoDTO equipoMedicoDTO) {
        // Realizar una solicitud POST al endpoint externo para crear un equipo
        Mono<EquipoMedicoDTO> equipoMedicoDTOMono = webClient.post()
                .uri("/") // Ruta del endpoint del servicio externo
                .body(Mono.just(equipoMedicoDTO), EquipoMedicoDTO.class) // Enviar el DTO como cuerpo de la solicitud
                .retrieve()
                .bodyToMono(EquipoMedicoDTO.class);
        // Mapear la respuesta al DTO
        EquipoMedicoDTO equipoMedicoDTO1 = equipoMedicoDTOMono.block();
        return equipoMedicoDTO1;
    }

    public void deleteEquipo(Integer id) {
        webClient.delete()
                .uri("/{id}", id)
                .retrieve()
                .toBodilessEntity()
                .block();
    }











}
