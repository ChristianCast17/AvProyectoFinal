package dgtic.core.clienteweb.controller.equipoMedico;

import dgtic.core.clienteweb.services.EquipoMedicoWebClientService;
import dgtic.core.dto.CategoriaDTO;
import dgtic.core.dto.EquipoMedicoDTO;
import dgtic.core.dto.TipoPaqueteDTO;
import dgtic.core.model.entities.Categoria;
import dgtic.core.model.entities.EquipoMedico;
import dgtic.core.model.entities.TipoPaquete;
import dgtic.core.service.categoria.CategoriaDTOService;
import dgtic.core.service.categoria.CategoriaService;
import dgtic.core.service.equipoMedico.EquipoMedicoService;
import dgtic.core.service.tipoPaquete.TipoPaqueteDTOService;
import dgtic.core.service.tipoPaquete.TipoPaqueteService;
import dgtic.core.util.RenderPagina;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class EquipoMedicoFrontController {

    private static final Logger log = LoggerFactory.getLogger(EquipoMedicoFrontController.class);

    @Autowired
    EquipoMedicoWebClientService equipoMedicoWebClientService;

    @Autowired
    TipoPaqueteDTOService tipoPaqueteDTOService;

    @Autowired
    CategoriaDTOService categoriaDTOService;

    @GetMapping(path = "/front/equiposMedicos/{id}")
    public String getEquipo(
            @PathVariable Integer id,
            Model model
    ){
        EquipoMedicoDTO equipoMedicoDTO = equipoMedicoWebClientService.getEquipoById(id);
        model.addAttribute("equipo", equipoMedicoDTO);
        return "equipoMedico/equipoMedicoDetalle";
    }

    @GetMapping(path = "/front/equiposMedicos/")
    public String getAllEquipos(Model model){
        model.addAttribute("equipos", equipoMedicoWebClientService.getAll());
        return "equipoMedico/equiposMedicos";
    }

    @GetMapping(path = "/front/equiposMedicos/crear")
    public String salvarEquipoMedico(Model model) {

        EquipoMedicoDTO equipoMedicoDTO = new EquipoMedicoDTO();
        List<CategoriaDTO> listaCategorias = categoriaDTOService.getCategoriaList()
                .stream()
                .map(c -> new CategoriaDTO(c.getIdCategoria(), c.getNombreCategoria()))
                .collect(Collectors.toList());

        List<TipoPaqueteDTO> listaPaquetes = tipoPaqueteDTOService.getTipoPaqueteList()
                .stream()
                .map(p -> new TipoPaqueteDTO(p.getIdTipoPaquete(), p.getNombrePaquete()))
                .collect(Collectors.toList());

        model.addAttribute("success", "Se almaceno el Equipo Medico con éxito");
        model.addAttribute("equipo", equipoMedicoDTO);
        model.addAttribute("selectCate", listaCategorias);
        model.addAttribute("selectTipo", listaPaquetes);
        equipoMedicoWebClientService.crearEquipo(equipoMedicoDTO);

        return "equipoMedico/alta-equipoMedico";
    }

    @GetMapping(path = "/front/equiposMedicos/{id}/editar")
    public String getFormEditar(@PathVariable Integer id, Model model){
        EquipoMedicoDTO equipoMedicoDTO = equipoMedicoWebClientService.getEquipoById(id);

        List<CategoriaDTO> listaCategorias = categoriaDTOService.getCategoriaList()
                .stream()
                .map(c -> new CategoriaDTO(c.getIdCategoria(), c.getNombreCategoria()))
                .collect(Collectors.toList());

        List<TipoPaqueteDTO> listaPaquetes = tipoPaqueteDTOService.getTipoPaqueteList()
                .stream()
                .map(p -> new TipoPaqueteDTO(p.getIdTipoPaquete(), p.getNombrePaquete()))
                .collect(Collectors.toList());

        model.addAttribute("equipo", equipoMedicoDTO);
        model.addAttribute("listaCategorias", listaCategorias);
        model.addAttribute("listaPaquetes", listaPaquetes);
        System.out.println(equipoMedicoDTO.toString());
        EquipoMedicoDTO equipoActualizado = equipoMedicoWebClientService.actualizaEquipo(equipoMedicoDTO);
        return "equipoMedico/formEditar";
    }

    @PutMapping(path = "/front/equiposMedicos/editar")
    public String actualizarEquipo(@RequestBody EquipoMedicoDTO equipoMedicoDTO, Model model){
        System.out.println("EQUIPO MEDICO DTO "+equipoMedicoDTO.toString());
        EquipoMedicoDTO equipoActualizado = equipoMedicoWebClientService.actualizaEquipo(equipoMedicoDTO);
        List<CategoriaDTO> listaCategorias = categoriaDTOService.getCategoriaList()
                .stream()
                .map(c -> new CategoriaDTO(c.getIdCategoria(), c.getNombreCategoria()))
                .collect(Collectors.toList());

        List<TipoPaqueteDTO> listaPaquetes = tipoPaqueteDTOService.getTipoPaqueteList()
                .stream()
                .map(p -> new TipoPaqueteDTO(p.getIdTipoPaquete(), p.getNombrePaquete()))
                .collect(Collectors.toList());

        model.addAttribute("listaCategorias", listaCategorias);
        model.addAttribute("listaPaquetes", listaPaquetes);
        model.addAttribute("equipo", equipoActualizado);
        return "equipoMedico/formEditar";
    }

    @GetMapping("/front/equiposMedicos/{id}/eliminar")
    public String eliminarEquipoMedico(@PathVariable Integer id, RedirectAttributes flash) {
        equipoMedicoWebClientService.deleteEquipo(id);
        flash.addFlashAttribute("success", "Equipo Medico Eliminado");
        return "redirect:/front/equiposMedicos/";
    }

}
