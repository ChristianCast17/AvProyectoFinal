package dgtic.core.model.entities;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity(name = "Remision")
@NamedQuery(
        name = "Remision.findByTipoPaquete",
        query = "SELECT r FROM Remision r WHERE r.tipoPaquete = :tipoPaquete"
)
@NamedQuery(
        name = "Remision.findByFechaEntregaAfter",
        query = "SELECT r FROM Remision r WHERE r.fechaEntrega >= :fecha"
)
public class Remision {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_remision")
    private Integer idRemision;
    private String cliente;

    @Column(name = "fecha_entrega")
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'hh:mm")
    private LocalDateTime fechaEntrega;

    @ManyToOne
    @JoinColumn(name = "id_tipo_paquete")
    private TipoPaquete tipoPaquete;

    public Remision() {
    }

    public Remision(Integer idRemision, String cliente, LocalDateTime fechaEntrega) {
        this.idRemision = idRemision;
        this.cliente = cliente;
        this.fechaEntrega = fechaEntrega;
    }

    public Integer getIdRemision() {
        return idRemision;
    }

    public void setIdRemision(Integer idRemision) {
        this.idRemision = idRemision;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public TipoPaquete getTipoPaquete() {
        return tipoPaquete;
    }

    public void setTipoPaquete(TipoPaquete tipoPaquete) {
        this.tipoPaquete = tipoPaquete;
    }

    public LocalDateTime getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(LocalDateTime fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Remision remision = (Remision) o;
        return Objects.equals(getIdRemision(), remision.getIdRemision()) && Objects.equals(getCliente(), remision.getCliente()) && Objects.equals(getTipoPaquete(), remision.getTipoPaquete()) && Objects.equals(getFechaEntrega(), remision.getFechaEntrega());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdRemision(), getCliente(), getTipoPaquete(), getFechaEntrega());
    }

    @Override
    public String toString() {
        return "Remision{" +
                "idRemision=" + idRemision +
                ", cliente='" + cliente + '\'' +
                ", tipoPaquete=" + tipoPaquete +
                ", fechaEntrega=" + fechaEntrega +
                '}';
    }
}
