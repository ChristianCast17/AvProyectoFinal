package dgtic.core.model.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "equiposmedicos")
@NamedQuery(
        name = "EquipoMedico.findByExistenciasGreaterThan",
        query = "SELECT e FROM EquipoMedico e WHERE e.existencias > :existencias"
)

public class EquipoMedico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_equipo_medico")
    private Integer id;
    @NotBlank(message = "El nombre NO puede estar vacio")
    private String nombreEquipo;

    @NotNull(message = "El campo existencias no puede ser nulo")
    @Min(value = 0, message = "Las existencias no pueden ser negativas")
    private Integer existencias;

    @ManyToOne
    @JoinColumn(name = "id_categoria")
    @JsonIgnore
    private Categoria categoria;

    @ManyToMany
    @JoinTable(
            name = "equipo_x_paquete",
            joinColumns = @JoinColumn(name = "id_equipo_medico",
                    referencedColumnName = "id_equipo_medico"),
            inverseJoinColumns = @JoinColumn(name = "id_tipo_paquete",
                    referencedColumnName = "id_tipo_paquete")
    )
    @JsonIgnore
    private List<TipoPaquete> paquetes = new ArrayList<>();

    public EquipoMedico() {
    }

//    public EquipoMedico(Integer codigoEquipo) {
//        this.id = id;
//    }

    public EquipoMedico(Integer idEquipoMedico, String nombreEquipo, Integer existencias, Categoria categoria) {
        this.id = idEquipoMedico;
        this.nombreEquipo = nombreEquipo;
        this.existencias = existencias;
        this.categoria = categoria;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

//    public Integer getCodigoEquipo() {
//        return id;
//    }
//
//    public void setCodigoEquipo(Integer codigoEquipo) {
//        this.id = codigoEquipo;
//    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public Integer getExistencias() {
        return existencias;
    }

    public void setExistencias(Integer existencias) {
        this.existencias = existencias;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public List<TipoPaquete> getPaquetes() {
        return paquetes;
    }

    public void setPaquetes(List<TipoPaquete> paquetes) {
        this.paquetes = paquetes;
    }

    public void addTipoPaquete(TipoPaquete paquete) {
        if (!paquetes.contains(paquete)) {
            paquetes.add(paquete);
            paquete.addEquipoMedico(this);
        }
    }
    public void removeTipoPaquete(TipoPaquete paquete) {
        if (paquetes.contains(paquete)) {
            paquetes.remove(paquete);
            paquete.removeEquipoMedico(this);
        }
    }

    @Override
    public String toString() {
        return "EquipoMedico{" +
                "id=" + id +
                ", nombreEquipo='" + nombreEquipo + '\'' +
                ", existencias=" + existencias +
                ", categoria=" + categoria +
                //", paquetes=" + paquetes +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EquipoMedico that = (EquipoMedico) o;
        return Objects.equals(id, that.id) && Objects.equals(getNombreEquipo(), that.getNombreEquipo()) && Objects.equals(getExistencias(), that.getExistencias()) && Objects.equals(getCategoria(), that.getCategoria()) && Objects.equals(getPaquetes(), that.getPaquetes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, getNombreEquipo(), getExistencias(), getCategoria(), getPaquetes());
    }
}
