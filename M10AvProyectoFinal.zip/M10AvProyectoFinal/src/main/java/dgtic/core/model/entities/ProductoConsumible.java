package dgtic.core.model.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity(name = "productoconsumible")
@NamedQuery(
        name = "ProductoConsumible.findByTipoPaqueteId",
        query = "SELECT p FROM productoconsumible p JOIN p.paquetes tp WHERE tp.idTipoPaquete = :idTipoPaquete"
)
public class ProductoConsumible {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto_consumible")
    private Integer idProductoConsumible;

    @NotBlank(message = "El nombre NO puede estar vacio")
    @Column(name = "nombre_producto")
    private String nombreProducto;

    private String descripcion;

    @NotNull(message = "El campo existencias no puede ser nulo")
    @Min(value = 0, message = "Las existencias no pueden ser negativas")
    private Integer existencias;

    @JsonIgnoreProperties(value = "productoConsumibles")
    @ManyToMany
    @JoinTable(
            name = "producto_x_paquete",
            joinColumns = @JoinColumn(name = "id_producto_consumible",
                    referencedColumnName = "id_producto_consumible"),
            inverseJoinColumns = @JoinColumn(name = "id_tipo_paquete",
                    referencedColumnName = "id_tipo_paquete")
    )
    @JsonIgnore
    private List<TipoPaquete> paquetes = new ArrayList<>();

    public ProductoConsumible() {
    }

    public ProductoConsumible(Integer idProductoConsumible, String nombreProducto, String descripcion, Integer existencias) {
        this.idProductoConsumible = idProductoConsumible;
        this.nombreProducto = nombreProducto;
        this.descripcion = descripcion;
        this.existencias = existencias;
    }

    public Integer getIdProductoConsumible() {
        return idProductoConsumible;
    }

    public void setIdProductoConsumible(Integer idProductoConsumible) {
        this.idProductoConsumible = idProductoConsumible;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getExistencias() {
        return existencias;
    }

    public void setExistencias(Integer existencias) {
        this.existencias = existencias;
    }

    public List<TipoPaquete> getPaquetes() {
        return paquetes;
    }

    public void setPaquetes(List<TipoPaquete> paquetes) {
        this.paquetes = paquetes;
    }

    public void addTipoPaquete(TipoPaquete paquete) {
        if (!paquetes.contains(paquete)) {
            paquetes.add(paquete);
            paquete.addProductoConsumible(this);
        }
    }
    public void removeTipoPaquete(TipoPaquete paquete) {
        if (paquetes.contains(paquete)) {
            paquetes.remove(paquete);
            paquete.removeProductoConsumible(this);
        }
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductoConsumible that = (ProductoConsumible) o;
        return Objects.equals(getIdProductoConsumible(), that.getIdProductoConsumible()) && Objects.equals(getNombreProducto(), that.getNombreProducto()) && Objects.equals(getDescripcion(), that.getDescripcion()) && Objects.equals(getExistencias(), that.getExistencias());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdProductoConsumible(), getNombreProducto(), getDescripcion(), getExistencias());
    }

    @Override
    public String toString() {
        return "ProductoConsumible{" +
                "idProductoConsumible=" + idProductoConsumible +
                ", nombreProducto='" + nombreProducto + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", existencias=" + existencias +
                '}';
    }
}
