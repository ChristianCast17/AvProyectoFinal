package dgtic.core.model.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "tipopaquete")
@NamedQuery(
        name = "TipoPaquete.buscarPorNombreContenga",
        query = "SELECT a FROM TipoPaquete a WHERE a.nombrePaquete LIKE CONCAT('%', :substring, '%')"
)

public class TipoPaquete {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="id_tipo_paquete")
    private Integer idTipoPaquete;

    @NotBlank(message = "El nombre NO puede estar vacio")
    @Column(name ="nombre_paquete")
    private String nombrePaquete;

    @JsonIgnore
    @ManyToMany(mappedBy = "paquetes")
    private Collection<EquipoMedico> equiposMedicos;

    @JsonIgnore
    @ManyToMany(mappedBy = "paquetes")
    private Collection<ProductoConsumible> productoConsumibles;

    @JsonIgnore
    @OneToMany(mappedBy = "tipoPaquete")
    private List<Remision> remisiones = new ArrayList<>();


    public TipoPaquete() {
    }

    public TipoPaquete(Integer idTipoPaquete, String nombrePaquete) {
        this.idTipoPaquete = idTipoPaquete;
        this.nombrePaquete = nombrePaquete;
    }

    public Integer getIdTipoPaquete() {
        return idTipoPaquete;
    }

    public void setIdTipoPaquete(Integer idTipoPaquete) {
        this.idTipoPaquete = idTipoPaquete;
    }

    public String getNombrePaquete() {
        return nombrePaquete;
    }

    public void setNombrePaquete(String nombrePaquete) {
        this.nombrePaquete = nombrePaquete;
    }

    public Collection<EquipoMedico> getEquiposMedicos() {
        return equiposMedicos;
    }

    public void setEquiposMedicos(Collection<EquipoMedico> equiposMedicos) {
        this.equiposMedicos = equiposMedicos;
    }

    public List<Remision> getRemisiones() {
        return remisiones;
    }

    public void setRemisiones(List<Remision> remisiones) {
        this.remisiones = remisiones;
    }

    public Collection<ProductoConsumible> getProductoConsumibles() {
        return productoConsumibles;
    }

    public void setProductoConsumibles(Collection<ProductoConsumible> productoConsumibles) {
        this.productoConsumibles = productoConsumibles;
    }

    public void addEquipoMedico(EquipoMedico equipo) {
        if (!getEquiposMedicos().contains(equipo)) {
            getEquiposMedicos().add(equipo);
        }
        if (!equipo.getPaquetes().contains(this)) {
            equipo.getPaquetes().add(this);
        }
    }

    public void removeEquipoMedico(EquipoMedico equipo) {
        if (equiposMedicos.contains(equipo)) {
            equiposMedicos.remove(equipo);
            equipo.getPaquetes().remove(this);
        }
    }

    public void addProductoConsumible(ProductoConsumible producto) {
        if (!getProductoConsumibles().contains(producto)) {
            getProductoConsumibles().add(producto);
        }
        if (!producto.getPaquetes().contains(this)) {
            producto.getPaquetes().add(this);
        }
    }

    public void removeProductoConsumible(ProductoConsumible producto) {
        if (productoConsumibles.contains(producto)) {
            productoConsumibles.remove(producto);
            producto.getPaquetes().remove(this);
        }
    }

    @Override
    public String toString() {
        return "TipoPaquete{" +
                "idTipoPaquete=" + idTipoPaquete +
                ", nombrePaquete='" + nombrePaquete + '\'' +
                //", equiposMedicos=" + equiposMedicos +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TipoPaquete that = (TipoPaquete) o;
        return Objects.equals(getIdTipoPaquete(), that.getIdTipoPaquete()) && Objects.equals(getNombrePaquete(), that.getNombrePaquete()) && Objects.equals(getEquiposMedicos(), that.getEquiposMedicos());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdTipoPaquete(), getNombrePaquete(), getEquiposMedicos());
    }
}
