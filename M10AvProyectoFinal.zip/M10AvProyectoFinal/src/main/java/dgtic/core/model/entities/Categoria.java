package dgtic.core.model.entities;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.validator.constraints.Length;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@NamedQuery(
        name = "Categoria.countAll",
        query = "SELECT COUNT(c) FROM Categoria c"
)
@NamedQuery(
        name = "Categoria.findWithEquiposMedicos",
        query = "SELECT DISTINCT c FROM Categoria c JOIN FETCH c.equipoMedicos"
)
@JsonIgnoreProperties(value = "equipoMedicos")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_categoria")
    private Integer idCategoria;

    @NotBlank
    @Length(min = 1, max = 100, message = "El nombre debe tener una longitud entre 1 y 100")
    @Column(name = "nombre_categoria")
    private String nombreCategoria;

    @OneToMany(mappedBy = "categoria")
    private List<EquipoMedico> equipoMedicos = new ArrayList<>();

    public Categoria() {
    }

    public Categoria(Integer idCategoria, String nombreCategoria) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
    }

    public Categoria(Integer idCategoria, String nombreCategoria, List<EquipoMedico> equipoMedicos) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
        this.equipoMedicos = equipoMedicos;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public List<EquipoMedico> getEquipoMedicos() {
        return equipoMedicos;
    }

    public void setEquipoMedicos(List<EquipoMedico> equipoMedicos) {
        this.equipoMedicos = equipoMedicos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Categoria categoria = (Categoria) o;
        return Objects.equals(getIdCategoria(), categoria.getIdCategoria()) && Objects.equals(getNombreCategoria(), categoria.getNombreCategoria());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdCategoria(), getNombreCategoria());
    }

    @Override
    public String toString() {
        return "Categoria{" +
                "idCategoria=" + idCategoria +
                ", nombreCategoria='" + nombreCategoria + '\'' +
                //", equipoMedicos=" + equipoMedicos +
                '}';
    }

}
